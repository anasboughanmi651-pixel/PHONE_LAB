#!/usr/bin/env python3
"""Tiny fake `adb` used by the tests: prints canned outputs like a real Android phone."""
import sys

args = sys.argv[1:]
serial = None
if args[:1] == ["-s"]:
    serial, args = args[1], args[2:]


def w(s):
    sys.stdout.write(s if s.endswith("\n") else s + "\n")


if args[:1] == ["devices"]:
    w("List of devices attached")
    w("R5CT12345AB\tdevice product:dm1q model:SM_S911B device:dm1q transport_id:1")
    w("0123456789ABCDEF\tunauthorized transport_id:2")
elif args[:1] == ["start-server"]:
    pass
elif args[:1] == ["version"]:
    w("Android Debug Bridge version 1.0.41 (fake)")
elif args[:1] == ["exec-out"]:
    sys.stdout.buffer.write(b"\x89PNG\r\n\x1a\n" + b"0" * 50)
elif args[:1] == ["pull"]:
    w("1 file pulled, 0 skipped. 12.3 MB/s (1024 bytes in 0.001s)")
elif args[:1] == ["shell"]:
    c = args[1]
    if c == "getprop":
        w("[ro.product.brand]: [samsung]\n[ro.product.manufacturer]: [samsung]\n[ro.product.model]: [SM-S911B]\n"
          "[ro.product.marketname]: [Galaxy S23]\n[ro.build.version.release]: [14]\n[ro.build.version.sdk]: [34]\n"
          "[ro.build.version.security_patch]: [2026-09-05]\n[ro.boot.flash.locked]: [1]\n[ro.product.cpu.abi]: [arm64-v8a]\n"
          "[ro.hardware]: [qcom]\n[gsm.sim.state]: [READY]\n[gsm.network.type]: [LTE]")
    elif c.startswith("dumpsys battery"):
        w("Current Battery Service state:\n  AC powered: false\n  USB powered: true\n  Wireless powered: false\n"
          "  status: 2\n  health: 2\n  present: true\n  level: 77\n  scale: 100\n  voltage: 4138\n  temperature: 311\n  technology: Li-ion")
    elif c.startswith("cat /proc/meminfo"):
        w("MemTotal:        8000000 kB\nMemFree:          500000 kB\nMemAvailable:    4800000 kB")
    elif c.startswith("head -3 /proc/meminfo"):
        w("MemTotal:        8000000 kB\nMemFree:          500000 kB\nMemAvailable:    4800000 kB\n@@\n1804000\n2112000\n@@\n2400000\n2400000\n@@\n0\n@@\n"
          "  level: 77\n  temperature: 315\n  voltage: 4130")
    elif c.startswith("df -k"):
        w("Filesystem       1K-blocks     Used Available Use% Mounted on\n/dev/block/dm-9  115343360 43000000  72000000  38% /data")
    elif c.startswith("pm list features"):
        for f in ("touchscreen", "touchscreen.multitouch", "camera", "camera.front", "camera.autofocus", "camera.flash", "wifi",
                  "bluetooth", "telephony", "location.gps", "nfc", "fingerprint", "microphone", "sensor.accelerometer",
                  "sensor.gyroscope", "sensor.proximity", "sensor.light", "sensor.compass", "sensor.barometer"):
            w("feature:android.hardware." + f)
        w("feature:com.google.android.feature.GOOGLE_BUILD")
    elif c.startswith("pm list packages -3 -i"):
        w("package:com.fake.risky  installer=null\npackage:com.fake.safe  installer=com.android.vending")
    elif c.startswith("pm list packages -3"):
        w("package:com.fake.risky\npackage:com.fake.safe")
    elif c.startswith("pm list packages"):
        w("package:com.fake.risky\npackage:com.fake.safe\npackage:com.android.settings\npackage:com.android.phone")
    elif c.startswith("wm size"):
        w("Physical size: 1080x2340\nPhysical density: 420")
    elif c.startswith("for f in /sys/devices/system/cpu"):
        w("1804000\n1804000\n2112000\n1996000\n@@\n2400000\n2400000\n2800000\n2800000\n@@\n8")
    elif c.startswith("for z in /sys/class/thermal"):
        w("cpu-0-0-usr\n38000\nbattery\n31000")
    elif c.startswith("cat /sys/class/power_supply"):
        w("512\n@@\n4500000\n@@\n5000000")
    elif c.startswith("settings get global wifi_on"):
        w("1")
    elif c.startswith("settings get global bluetooth_on"):
        w("0")
    elif c.startswith("dumpsys diskstats"):
        w("App Size: 2000000000\nPhotos Size: 5000000000\nVideos Size: 1000000000\nAudio Size: 100000000\nSystem Size: 9000000000\nOther Size: 900000000")
    elif c.startswith("dumpsys package com.fake.risky"):
        w("    android.permission.READ_SMS: granted=true\n    android.permission.SYSTEM_ALERT_WINDOW: granted=true\n"
          "    android.permission.CAMERA: granted=true\n    android.permission.RECORD_AUDIO: granted=true\n"
          "    android.permission.INTERNET: granted=true")
    elif c.startswith("dumpsys package"):
        w("    android.permission.INTERNET: granted=true")
    elif c.startswith("ls -la"):
        w("total 8\ndrwxrws--x 4 u0_a123 media_rw 3452 2026-01-01 12:00 DCIM\n-rw-rw---- 1 u0_a123 media_rw 1048576 2026-02-03 08:15 My Notes.pdf\n"
          "drwxrws--x 2 u0_a123 media_rw 3452 2026-01-01 12:00 .\n")
    elif c.startswith("dd if=/dev/zero"):
        w("32+0 records in\n32+0 records out\n33554432 bytes (32 M) copied\n-rw------- 1 shell shell 33554432 2026-11-12 10:00 /data/local/tmp/pl_test.bin")
    elif c.startswith("cmd vibrator"):
        w("")
    elif c.startswith("find /sdcard"):
        w("/sdcard/Download/free_game.apk")
    elif c.startswith("ls /sdcard/Download"):
        w("invoice.pdf.apk\nphoto.jpg")
    elif c.startswith("ls -d"):
        w(c.split()[-1])
    elif c.startswith("getprop gsm.sim.state"):
        w("READY")
    else:
        w("")
else:
    sys.stderr.write("fake adb: unknown\n")
    sys.exit(1)
