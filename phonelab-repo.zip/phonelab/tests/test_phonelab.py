import json
import os
import sys
import threading
import time
import unittest
import urllib.error
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
import stat
import tempfile
_W = os.path.join(tempfile.mkdtemp(prefix="fakeadb_"), "adb")
with open(_W, "w") as _f:  # wrapper created at runtime: GitHub uploads do not keep the executable bit
    _f.write('#!/bin/sh\nexec "%s" "%s" "$@"\n' % (sys.executable, os.path.join(HERE, "fake_adb.py")))
os.chmod(_W, os.stat(_W).st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
os.environ["PHONELAB_ADB"] = _W
import phonelab as P  # noqa: E402


class Parsers(unittest.TestCase):
    def test_devices(self):
        d = P.parse_devices("List of devices attached\nABC123\tdevice usb:1-1 model:Pixel_7 transport_id:3\nXYZ\tunauthorized\n")
        self.assertEqual([x["state"] for x in d], ["device", "unauthorized"])
        self.assertEqual(d[0]["model"], "Pixel_7")

    def test_battery(self):
        b = P.parse_battery("  status: 3\n  health: 2\n  level: 55\n  temperature: 287\n  voltage: 3900\n  USB powered: false")
        self.assertEqual((b["level"], b["temp_c"], b["health"], b["status"]), (55, 28.7, "Good", "Discharging"))

    def test_meminfo_df(self):
        m = P.parse_meminfo("MemTotal: 1000000 kB\nMemAvailable: 250000 kB")
        self.assertEqual(m["used_pct"], 75)
        self.assertIsNone(P.parse_meminfo("garbage"))
        d = P.parse_df("Filesystem 1K-blocks Used Available Use% Mounted on\n/dev/block/dm-9 1048576 524288 524288 50% /data")
        self.assertEqual((d["total_gb"], d["used_pct"]), (1.0, 50))
        self.assertIsNone(P.parse_df(""))

    def test_ls_with_spaces(self):
        r = P.parse_ls("drwxrws--x 4 u0 media_rw 3452 2026-01-01 12:00 DCIM\n-rw-rw---- 1 u0 media_rw 10 2026-01-01 12:00 My Notes.pdf")
        self.assertEqual([e["name"] for e in r], ["DCIM", "My Notes.pdf"])
        self.assertTrue(r[0]["dir"])

    def test_perms_risk(self):
        perms = P.parse_perms("android.permission.READ_SMS: granted=true\nandroid.permission.SYSTEM_ALERT_WINDOW: granted=true\nandroid.permission.CAMERA: granted=false")
        self.assertEqual(len(perms), 2)
        self.assertEqual(P.assess(perms, True)[0], "hg")
        self.assertEqual(P.assess([], False)[0], "lw")

    def test_tests_available(self):
        t = P.tests_available(["android.hardware.touchscreen", "android.hardware.wifi"])
        self.assertIn("Touchscreen", t)
        self.assertIn("Battery", t)
        self.assertNotIn("NFC", t)


class Server(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.srv = P.make_server(0)
        cls.port = cls.srv.server_address[1]
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()
        P.ADB.path = None
        import shutil, tempfile
        P.DATA = tempfile.mkdtemp(prefix="phonelab_test_")
        cls.tmp = P.DATA

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()
        import shutil
        shutil.rmtree(cls.tmp, ignore_errors=True)

    def get(self, path, method="GET", body=None, token=True):
        req = urllib.request.Request("http://127.0.0.1:%d%s" % (self.port, path), method=method)
        if token:
            req.add_header("X-PL-Token", P.TOKEN)
        if body is not None:
            req.add_header("Content-Type", "application/json")
            req.data = json.dumps(body).encode()
        try:
            with urllib.request.urlopen(req, timeout=20) as r:
                return r.status, r.read(), r.headers.get("Content-Type")
        except urllib.error.HTTPError as e:
            return e.code, e.read(), e.headers.get("Content-Type")

    def j(self, *a, **k):
        code, body, _ = self.get(*a, **k)
        return code, json.loads(body.decode())

    def wait_job(self, jid):
        for _ in range(150):
            code, j = self.j("/api/job?id=" + jid)
            if j["status"] != "running":
                return j
            time.sleep(0.1)
        self.fail("job timeout")

    def test_forbidden_without_token(self):
        self.assertEqual(self.get("/api/devices", token=False)[0], 403)

    def test_index_gets_token(self):
        code, body, ctype = self.get("/", token=False)
        if code == 200:
            self.assertIn(P.TOKEN, body.decode())
            self.assertNotIn("__TOKEN__", body.decode())

    def test_devices_and_info(self):
        code, d = self.j("/api/devices")
        self.assertEqual([x["state"] for x in d["devices"]], ["device", "unauthorized"])
        code, i = self.j("/api/info?serial=R5CT12345AB")
        self.assertEqual(i["name"], "Samsung Galaxy S23")
        self.assertEqual(i["android"], "14")
        self.assertEqual(i["battery"]["level"], 77)
        self.assertEqual(i["battery"]["health_pct"], 90)
        self.assertEqual(i["memory"]["used_pct"], 40)
        self.assertEqual(i["cpu"]["cores"], 8)
        self.assertEqual(i["cpu"]["temp_c"], 38.0)
        self.assertEqual(i["storage"]["total_gb"], 110.0)
        self.assertEqual(i["sensors"], 6)
        self.assertIn("Gyroscope", i["tests"])
        self.assertIsNone(i["imei"])
        self.assertEqual(sum(i["stor_split"]), 100)

    def test_unauthorized_and_bad_serial(self):
        code, i = self.j("/api/info?serial=0123456789ABCDEF")
        self.assertEqual(i["error"], "unauthorized")
        self.assertEqual(self.j("/api/info?serial=bad%20serial;rm")[0], 400)

    def test_autotests(self):
        code, r = self.j("/api/autotests", "POST", {"serial": "R5CT12345AB", "names": ["Battery", "Storage", "WiFi", "Bluetooth", "SIM Reader", "Vibration", "Charge"]})
        self.assertEqual(r["Battery"]["result"], 1)
        self.assertEqual(r["Storage"]["result"], 1)
        self.assertEqual(r["WiFi"]["result"], 1)
        self.assertEqual(r["Bluetooth"]["result"], 0)
        self.assertEqual(r["Vibration"]["result"], 0)
        self.assertEqual(r["Charge"]["result"], 1)

    def test_scan_job(self):
        code, r = self.j("/api/scan", "POST", {"serial": "R5CT12345AB"})
        job = self.wait_job(r["job"])
        self.assertEqual(job["status"], "done")
        names = [x[0] for x in job["result"]["items"]]
        self.assertIn("com.fake.risky", names)
        self.assertNotIn("com.fake.safe", names)
        self.assertIn("invoice.pdf.apk", names)

    def test_apps_job(self):
        code, r = self.j("/api/apps", "POST", {"serial": "R5CT12345AB"})
        job = self.wait_job(r["job"])
        rows = job["result"]["apps"]
        self.assertEqual(rows[0][0], "com.fake.risky")
        self.assertEqual(rows[-1][2], "lw")

    def test_files_screen_live(self):
        code, f = self.j("/api/files?serial=R5CT12345AB&path=/sdcard")
        self.assertEqual([e["name"] for e in f["entries"]], ["DCIM", "My Notes.pdf"])
        code, body, ctype = self.get("/api/screen?serial=R5CT12345AB")
        self.assertEqual((code, ctype), (200, "image/png"))
        code, lv = self.j("/api/live?serial=R5CT12345AB")
        self.assertEqual((lv["ram"], lv["bat"]), (40, 77))

    def test_report_roundtrip(self):
        self.assertIsNone(self.j("/api/report?serial=T1")[1]["snapshot"])
        self.j("/api/report", "POST", {"serial": "T1", "snapshot": {"a": 1}})
        self.assertEqual(self.j("/api/report?serial=T1")[1]["snapshot"], {"a": 1})

    def test_backup_job(self):
        code, r = self.j("/api/backup", "POST", {"serial": "R5CT12345AB"})
        self.assertEqual(self.wait_job(r["job"])["status"], "done")


if __name__ == "__main__":
    unittest.main()
