#!/usr/bin/env python3
"""Fake libimobiledevice tools (ideviceinfo, idevicediagnostics, idevicepair, idevicescreenshot, ideviceinstaller)."""
import plistlib
import sys

tool, args = sys.argv[1], sys.argv[2:]
udid = args[args.index("-u") + 1] if "-u" in args else ""
rest = [a for i, a in enumerate(args) if a != "-u" and (i == 0 or args[i - 1] != "-u")]
PAIRED = udid == "00008030-001E1D2A3C42802E"


def emit(obj):
    sys.stdout.write(plistlib.dumps(obj).decode())


if tool == "idevicepair":
    if rest[:1] == ["validate"]:
        if PAIRED:
            print("SUCCESS: Validated pairing with device " + udid)
        else:
            print("ERROR: Please enter the passcode on the device and retry.")
            sys.exit(1)
    elif rest[:1] == ["pair"]:
        print("SUCCESS: Paired with device " + udid)
elif not PAIRED:
    sys.stderr.write("ERROR: Could not connect to lockdownd, error code -17\n")
    sys.exit(255)
elif tool == "ideviceinfo":
    if "-q" in rest:
        dom = rest[rest.index("-q") + 1]
        if dom == "com.apple.mobile.battery":
            emit({"BatteryCurrentCapacity": 77, "BatteryIsCharging": True, "ExternalChargeCapable": True, "FullyCharged": False})
        elif dom == "com.apple.disk_usage":
            emit({"TotalDiskCapacity": 64000000000, "TotalDataCapacity": 60000000000, "TotalDataAvailable": 11960000000})
    else:
        emit({"DeviceName": "Test iPhone", "ProductType": "iPhone10,3", "ProductVersion": "16.7.2", "BuildVersion": "20H115",
              "SerialNumber": "F2LXXXXXXXXX", "UniqueDeviceID": udid, "InternationalMobileEquipmentIdentity": "353012345678901",
              "ModelNumber": "MQAD2", "RegionInfo": "ZD/A", "ActivationState": "Activated", "WiFiAddress": "aa:bb:cc:dd:ee:ff",
              "BluetoothAddress": "aa:bb:cc:dd:ee:00", "CPUArchitecture": "arm64", "HardwareModel": "D221AP"})
elif tool == "idevicediagnostics":
    sys.stdout.write("log line before the plist\n")
    emit({"IORegistryEntryChildren": [{"CycleCount": 10, "DesignCapacity": 2716, "NominalChargeCapacity": 2650,
                                       "Temperature": 3012, "Voltage": 4210}]})
elif tool == "idevicescreenshot":
    with open(rest[-1], "wb") as f:
        f.write(b"\x89PNG\r\n\x1a\n" + b"1" * 40)
elif tool == "ideviceinstaller":
    print("CFBundleIdentifier, CFBundleVersion, CFBundleDisplayName")
    print('com.example.chat, "3.1", "Chat"')
    print('com.example.maps, "1.0.2", "Maps"')
