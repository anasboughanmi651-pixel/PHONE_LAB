@echo off
REM Build PHONELAB.exe on your own Windows PC (Python 3.8 recommended for Windows 7 support).
REM 1) put adb.exe, AdbWinApi.dll, AdbWinUsbApi.dll in the "tools" folder first.
python -m pip install pyinstaller==5.13.2
pyinstaller --noconfirm --onedir --name PHONELAB --add-data "ui;ui" --add-data "tools;tools" phonelab.py
echo.
echo Done: dist\PHONELAB\PHONELAB.exe
pause
