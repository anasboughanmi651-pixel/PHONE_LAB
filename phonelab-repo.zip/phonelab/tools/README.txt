adb.exe, AdbWinApi.dll and AdbWinUsbApi.dll go here (they are added automatically by the GitHub build).
Running from source on Windows? Copy these three files from Google's "platform-tools" into this folder,
or install platform-tools and add it to PATH. You can also set PHONELAB_ADB=C:\path\to\adb.exe
