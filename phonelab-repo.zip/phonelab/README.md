# CHARARA => PHONELAB  ·  Universal Device Intelligence

Programme Windows portable (sans installation) qui lit l'état réel d'un téléphone **Android** branché en USB
(via ADB) et l'affiche dans l'interface PHONELAB (français / English / العربية, mode sombre).
Windows 7 SP1 et plus. Aucune dépendance Python à installer : tout est dans le dossier.

## Obtenir PHONELAB.exe (GitHub)
1. Sur github.com : **New repository** (ex. `phonelab`), puis **Add file > Upload files** et envoyez **tout** le contenu
   de ce dossier (y compris le dossier caché `.github`). Sinon : *Create new file* et tapez `.github/workflows/build.yml`.
2. Onglet **Actions > build-windows > Run workflow** (3 à 6 minutes). Si les tests ou le build échouent, ouvrez l'étape rouge.
3. Téléchargez l'artefact **PHONELAB-windows** (zip). Pour une page de téléchargement permanente : créez un tag
   `v0.5.0` (Releases > Draft a new release), le zip sera attaché automatiquement.
4. Sur le PC : décompressez, lancez **PHONELAB.exe**. Le navigateur s'ouvre sur `http://127.0.0.1:8765`.

## Brancher le téléphone
1. Réglages > À propos > touchez 7 fois « Numéro de build ».
2. Réglages > Options pour les développeurs > **Débogage USB**.
3. Câble de **données**, puis acceptez « Autoriser le débogage USB ? » sur le téléphone.
4. Windows 7 : installez le pilote USB du constructeur (Samsung, Xiaomi, Huawei...) si le téléphone n'apparaît pas.

## Windows 7
- Python 3.8 (dernière version compatible) est utilisé pour la compilation. Installez les mises à jour Windows
  (SP1 + KB2999226 / Visual C++ 2015-2019 redistributable) si PHONELAB.exe ne démarre pas.
- Navigateur : **Chrome 109** ou **Firefox ESR 115** (les derniers qui tournent sur Windows 7). Internet Explorer ne marche pas.
- La version d'`adb` téléchargée par le workflow (r34.0.5) n'a pas été vérifiée sur Windows 7. Si adb ne démarre pas, mettez un autre
  `adb.exe` dans le dossier `tools` à côté de `PHONELAB.exe`.

## Ce qui est lu pour de vrai (Android)
Modèle, version, patch de sécurité, batterie (niveau, température, tension, état, cycles/santé si le téléphone les expose),
RAM, stockage, processeur (cœurs, fréquences, température si lisible), écran, capteurs/fonctions présents, applis,
Wi-Fi/Bluetooth/SIM, capture d'écran en direct, parcours de fichiers, copie vers le PC (`Documents\PHONELAB\<série>`),
sauvegarde DCIM/Pictures/Documents/Download, rapport de référence et comparaison avec le précédent.
Tests automatiques : Batterie, Charge, Stockage (écriture 32 Mo), Wi-Fi, Bluetooth, SIM. Les autres tests restent manuels (PASS/FAIL).

## Limites (honnêtement)
- **Pas testé sur un vrai téléphone ni sur Windows** : le code est testé avec un faux `adb`. Premier essai réel = ici.
- **iPhone : pas encore** (l'interface démo l'affiche, la version réelle ne lit que l'Android).
- **IMEI non lu** (Android 10+ le réserve au système). Santé batterie / cycles : seulement si exposés.
- **Menaces = analyse heuristique** (permissions, source d'installation, noms de fichiers), pas un antivirus.
  Quarantaine/suppression sur le téléphone : pas encore disponible.
- Authenticité des pièces (écran, batterie) : **non vérifiable** par ADB. L'interface le dit au lieu de deviner.
- adb vient de Google (platform-tools) : vérifiez ses conditions de licence si vous distribuez le programme publiquement.

## Dépannage
| Problème | Solution |
|---|---|
| « ADB introuvable » | Mettez `adb.exe` + `AdbWinApi.dll` + `AdbWinUsbApi.dll` dans `tools\` |
| Téléphone « unauthorized » | Acceptez la fenêtre sur le téléphone ; sinon Options développeur > Révoquer les autorisations USB |
| Téléphone « offline » | Débranchez/rebranchez, changez de câble ou de port |
| Port occupé | PHONELAB essaie 8765 à 8784 tout seul |
| Un problème | Journal : `%LOCALAPPDATA%\PHONELAB\phonelab.log` |

---
## بالعربية (تونسي)
برنامج ويندوز بدون تثبيت يقرا حالة هاتف **Android** حقيقي عبر USB ويعرضها في واجهة PHONELAB.
1. ارفع كل الملفات في GitHub (مع مجلد `.github`) ثم Actions > build-windows > Run workflow.
2. نزّل **PHONELAB-windows** (zip) من الـ Artifacts، فكّو، وشغّل **PHONELAB.exe**.
3. في الهاتف: خيارات المطور > **تصحيح USB**، كابل بيانات، ووافق على النافذة.
4. ويندوز 7: استعمل Chrome 109 ولا Firefox ESR 115، ونزّل تعريف USB تاع الشركة.

مهم: الكود مختبر بـ adb وهمي كان، والتجربة الحقيقية الأولى هي معاك. الآيفون مازال. والـ IMEI ما يتقراش.
