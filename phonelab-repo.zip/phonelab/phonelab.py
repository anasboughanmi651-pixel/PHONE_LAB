#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CHARARA => PHONELAB: local web server + ADB bridge.

Python 3.8+ (works on Windows 7 and up), standard library only.
Binds to 127.0.0.1 only. Every ADB call has a timeout and every request is
wrapped so that one failing phone or command can never crash the program.
"""
import argparse
import json
import logging
import os
import platform
import re
import secrets
import shlex
import shutil
import socket
import subprocess
import sys
import threading
import time
import traceback
import webbrowser
from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from logging.handlers import RotatingFileHandler
from urllib.parse import parse_qs, urlparse

VERSION = "0.5.0"
FROZEN = getattr(sys, "frozen", False)
BASE = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
HERE = os.path.dirname(sys.executable) if FROZEN else os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), "PHONELAB")
NOWIN = 0x08000000 if os.name == "nt" else 0
TOKEN = secrets.token_hex(16)
LOG = logging.getLogger("phonelab")

CANON = ["Touchscreen", "Multitouch", "Dead Pixel", "LCD", "Speaker", "Microphone", "Headphones",
         "Hardware Buttons", "Battery", "Rear Camera", "Front Camera", "Autofocus", "Flash", "Vibration",
         "Storage", "Charge", "Accelerometer", "Gyroscope", "Proximity Sensor", "Light Sensor",
         "Magnetic Sensor", "Call", "WiFi", "Bluetooth", "GPS", "NFC", "Fingerprint Sensor", "Barometer",
         "SIM Reader"]
NEED = {"Touchscreen": "android.hardware.touchscreen", "Multitouch": "android.hardware.touchscreen.multitouch",
        "Microphone": "android.hardware.microphone", "Rear Camera": "android.hardware.camera",
        "Front Camera": "android.hardware.camera.front", "Autofocus": "android.hardware.camera.autofocus",
        "Flash": "android.hardware.camera.flash", "Accelerometer": "android.hardware.sensor.accelerometer",
        "Gyroscope": "android.hardware.sensor.gyroscope", "Proximity Sensor": "android.hardware.sensor.proximity",
        "Light Sensor": "android.hardware.sensor.light", "Magnetic Sensor": "android.hardware.sensor.compass",
        "Barometer": "android.hardware.sensor.barometer", "Fingerprint Sensor": "android.hardware.fingerprint",
        "Call": "android.hardware.telephony", "SIM Reader": "android.hardware.telephony",
        "WiFi": "android.hardware.wifi", "Bluetooth": "android.hardware.bluetooth",
        "GPS": "android.hardware.location.gps", "NFC": "android.hardware.nfc"}
DANGEROUS = {"READ_SMS", "SEND_SMS", "RECEIVE_SMS", "READ_CONTACTS", "WRITE_CONTACTS", "READ_CALL_LOG",
             "RECORD_AUDIO", "CAMERA", "ACCESS_FINE_LOCATION", "SYSTEM_ALERT_WINDOW",
             "BIND_ACCESSIBILITY_SERVICE", "REQUEST_INSTALL_PACKAGES", "READ_PHONE_STATE", "CALL_PHONE"}
STATUS = {1: "Unknown", 2: "Charging", 3: "Discharging", 4: "Not charging", 5: "Full"}
HEALTH = {1: "Unknown", 2: "Good", 3: "Overheat", 4: "Dead", 5: "Over voltage", 6: "Failure", 7: "Cold"}
SERIAL_RE = re.compile(r"^[A-Za-z0-9._:\-]{1,64}$")


# ----------------------------------------------------------------- parsers (pure functions)
def parse_devices(text):
    out = []
    for line in (text or "").splitlines():
        line = line.strip()
        if not line or line.startswith("List of devices") or line.startswith("*"):
            continue
        parts = line.split()
        if len(parts) < 2:
            continue
        d = {"serial": parts[0], "state": parts[1]}
        for p in parts[2:]:
            if ":" in p:
                k, v = p.split(":", 1)
                d[k] = v
        out.append(d)
    return out


def parse_props(text):
    props = {}
    for m in re.finditer(r"^\[(.+?)\]: \[(.*)\]\s*$", text or "", re.M):
        props[m.group(1)] = m.group(2)
    return props


def _int(v):
    try:
        return int(str(v).strip())
    except (TypeError, ValueError):
        return None


def parse_battery(text):
    kv = {}
    for line in (text or "").splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            kv[k.strip()] = v.strip()
    temp = _int(kv.get("temperature"))
    status = _int(kv.get("status"))
    health = _int(kv.get("health"))
    return {"level": _int(kv.get("level")), "scale": _int(kv.get("scale")) or 100,
            "temp_c": round(temp / 10.0, 1) if temp is not None else None,
            "voltage_mv": _int(kv.get("voltage")), "status": STATUS.get(status, "Unknown"),
            "health": HEALTH.get(health, "Unknown"), "present": kv.get("present", "true") == "true",
            "ac": kv.get("AC powered") == "true", "usb": kv.get("USB powered") == "true",
            "wireless": kv.get("Wireless powered") == "true", "technology": kv.get("technology")}


def parse_meminfo(text):
    d = {}
    for m in re.finditer(r"^(MemTotal|MemAvailable):\s+(\d+) kB", text or "", re.M):
        d[m.group(1)] = int(m.group(2))
    if "MemTotal" not in d:
        return None
    avail = d.get("MemAvailable", 0)
    return {"total_mb": round(d["MemTotal"] / 1024.0), "avail_mb": round(avail / 1024.0),
            "used_pct": round(100.0 * (d["MemTotal"] - avail) / d["MemTotal"])}


def parse_df(text):
    lines = [l for l in (text or "").splitlines() if l.strip()]
    if len(lines) < 2:
        return None
    nums = [int(t) for t in " ".join(lines[1:]).split() if t.isdigit()]
    if len(nums) < 3 or nums[0] <= 0:
        return None
    total, used = nums[0], nums[1]
    return {"total_gb": round(total / 1048576.0, 1), "used_gb": round(used / 1048576.0, 1),
            "used_pct": round(100.0 * used / total)}


def parse_features(text):
    return sorted({m.group(1) for m in re.finditer(r"^feature:([\w.\-]+)", text or "", re.M)})


def parse_pkgs(text):
    out = []
    for m in re.finditer(r"^package:(\S+)(?:\s+installer=(\S+))?", text or "", re.M):
        out.append((m.group(1), m.group(2)))
    return out


LS_FULL = re.compile(r"^([\-dlcbps][rwxsStT\-]{9})\s+\d+\s+\S+\s+\S+\s+(\d+)\s+(\d{4}-\d{2}-\d{2})\s+(\d{2}:\d{2})\s+(.+)$")
LS_OLD = re.compile(r"^([\-dlcbps][rwxsStT\-]{9})\s+\S+\s+\S+\s+(\d+)?\s*(\w{3}\s+\d+\s+[\d:]+)\s+(.+)$")


def parse_ls(text):
    out = []
    for line in (text or "").splitlines():
        m = LS_FULL.match(line.rstrip())
        if m:
            name, size, date = m.group(5), int(m.group(2)), m.group(3) + " " + m.group(4)
            perm = m.group(1)
        else:
            m = LS_OLD.match(line.rstrip())
            if not m:
                continue
            name, size, date, perm = m.group(4), int(m.group(2) or 0), m.group(3), m.group(1)
        if perm[0] == "l" and " -> " in name:
            name = name.split(" -> ")[0]
        if name in (".", ".."):
            continue
        out.append({"name": name, "dir": perm[0] in "dl", "size": size, "date": date})
    out.sort(key=lambda e: (not e["dir"], e["name"].lower()))
    return out


PERM_RE = re.compile(r"([A-Za-z0-9_.]*permission\.[A-Z0-9_]+): granted=true")


def parse_perms(text):
    return sorted(set(PERM_RE.findall(text or "")))


def assess(perms, sideloaded):
    dang = sorted({p.split(".")[-1] for p in perms if p.split(".")[-1] in DANGEROUS})
    score = len(dang) + (2 if sideloaded else 0)
    if "SYSTEM_ALERT_WINDOW" in dang or "BIND_ACCESSIBILITY_SERVICE" in dang:
        score += 3
    if any(x in dang for x in ("READ_SMS", "SEND_SMS", "RECEIVE_SMS")):
        score += 2
    return ("hg" if score >= 8 else "e3s" if score >= 4 else "lw"), dang


def parse_diskstats(text):
    d = {}
    for m in re.finditer(r"^(App Size|Photos Size|Videos Size|Audio Size|Downloads Size|System Size|Other Size):\s*(\d+)", text or "", re.M):
        d[m.group(1)] = int(m.group(2))
    if not d:
        return None
    photos, apps, video = d.get("Photos Size", 0), d.get("App Size", 0), d.get("Videos Size", 0)
    other = sum(v for k, v in d.items() if k not in ("Photos Size", "App Size", "Videos Size", "System Size"))
    tot = float(photos + apps + video + other) or 1.0
    return [round(100 * photos / tot), round(100 * apps / tot), round(100 * video / tot), round(100 * other / tot)]


def _ints(block):
    return [int(x) for x in block.split() if x.isdigit()]


def parse_cpu(text):
    parts = (text or "").split("@@")
    cur = [round(v / 1000.0) for v in _ints(parts[0])] if parts else []
    mx = [round(v / 1000.0) for v in _ints(parts[1])] if len(parts) > 1 else []
    cores = (_ints(parts[2]) or [len(cur)])[0] if len(parts) > 2 else len(cur)
    pct = None
    if cur and mx and len(cur) == len(mx):
        pct = round(100.0 * sum(c / float(m) for c, m in zip(cur, mx) if m) / len(cur))
    return {"cores": cores, "freqs_mhz": cur, "load_pct": pct}


def parse_thermal(text):
    lines = [l.strip() for l in (text or "").splitlines() if l.strip()]
    best = None
    for i in range(0, len(lines) - 1, 2):
        kind, val = lines[i].lower(), _int(lines[i + 1])
        if val is None or not re.search(r"cpu|soc|tsens|ap|big|little|mtktscpu", kind):
            continue
        c = val / 1000.0 if val > 1000 else float(val)
        if 15 <= c <= 120:
            best = c if best is None else max(best, c)
    return round(best, 1) if best is not None else None


def tests_available(features):
    fs = set(features)
    return [n for n in CANON if n not in NEED or NEED[n] in fs]


# ----------------------------------------------------------------- adb wrapper
def find_adb():
    env = os.environ.get("PHONELAB_ADB")
    if env and os.path.isfile(env):
        return env
    exe = "adb.exe" if os.name == "nt" else "adb"
    for d in (os.path.join(HERE, "tools"), os.path.join(BASE, "tools"), HERE):
        p = os.path.join(d, exe)
        if os.path.isfile(p):
            return p
    p = shutil.which("adb")
    if p:
        return p
    for var in ("ANDROID_HOME", "ANDROID_SDK_ROOT"):
        root = os.environ.get(var)
        if root:
            p = os.path.join(root, "platform-tools", exe)
            if os.path.isfile(p):
                return p
    return None


def run(args, timeout=15, binary=False):
    try:
        p = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout, creationflags=NOWIN)
        out = p.stdout if binary else p.stdout.decode("utf-8", "replace")
        return p.returncode, out, p.stderr.decode("utf-8", "replace")
    except subprocess.TimeoutExpired:
        return -9, (b"" if binary else ""), "timeout"
    except Exception as e:  # missing file, permission, antivirus block...
        return -1, (b"" if binary else ""), str(e)


def run_quiet(args, timeout=25):
    try:
        return subprocess.run(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=timeout, creationflags=NOWIN).returncode
    except Exception:
        return -1


class Adb:
    def __init__(self):
        self.path = None
        self.started = False
        self.lock = threading.Lock()

    def cmd(self, serial, *args, **kw):
        if not self.path:
            self.path = find_adb()
        if not self.path:
            return -2, "", "adb not found"
        a = [self.path] + (["-s", serial] if serial else []) + list(args)
        return run(a, kw.get("timeout", 15), kw.get("binary", False))

    def sh(self, serial, command, timeout=15):
        return self.cmd(serial, "shell", command, timeout=timeout)

    def start(self):
        # stdout/stderr go to DEVNULL: on Windows the adb daemon inherits pipe
        # handles and a captured start-server call would hang until the timeout.
        with self.lock:
            if not self.started:
                if not self.path:
                    self.path = find_adb()
                if not self.path:
                    return False
                self.started = run_quiet([self.path, "start-server"]) == 0
        return self.started

    def devices(self):
        self.start()
        rc, out, err = self.cmd(None, "devices", "-l", timeout=15)
        if rc not in (0, -2):
            self.started = False  # server probably died: restart it on the next poll
        return rc, parse_devices(out), err


ADB = Adb()


def ver_line():
    rc, out, _ = ADB.cmd(None, "version", timeout=8)
    return out.splitlines()[0] if rc == 0 and out else None


# ----------------------------------------------------------------- data collection
def collect_info(serial):
    rc, devs, err = ADB.devices()
    if rc == -2:
        return {"error": "adb_missing"}
    dev = next((d for d in devs if d["serial"] == serial), None)
    if not dev:
        return {"error": "not_found"}
    if dev["state"] != "device":
        return {"error": dev["state"], "serial": serial}
    cmds = {
        "props": "getprop", "battery": "dumpsys battery", "mem": "cat /proc/meminfo", "df": "df -k /data",
        "features": "pm list features", "pk3": "pm list packages -3", "pkall": "pm list packages",
        "wm": "wm size; wm density",
        "cpu": "for f in /sys/devices/system/cpu/cpu[0-9]*/cpufreq/scaling_cur_freq; do cat $f 2>/dev/null; done; echo @@; "
               "for f in /sys/devices/system/cpu/cpu[0-9]*/cpufreq/cpuinfo_max_freq; do cat $f 2>/dev/null; done; echo @@; "
               "grep -c ^processor /proc/cpuinfo",
        "thermal": "for z in /sys/class/thermal/thermal_zone*; do cat $z/type 2>/dev/null; cat $z/temp 2>/dev/null; done",
        "cyc": "cat /sys/class/power_supply/battery/cycle_count 2>/dev/null; echo @@; "
               "cat /sys/class/power_supply/battery/charge_full 2>/dev/null; echo @@; "
               "cat /sys/class/power_supply/battery/charge_full_design 2>/dev/null",
        "wifi": "settings get global wifi_on", "bt": "settings get global bluetooth_on",
        "disk": "dumpsys diskstats",
    }
    with ThreadPoolExecutor(max_workers=6) as ex:
        futs = {k: ex.submit(ADB.sh, serial, c, 25) for k, c in cmds.items()}
        raw = {k: f.result()[1] for k, f in futs.items()}
    props = parse_props(raw["props"])
    feats = parse_features(raw["features"])
    bat = parse_battery(raw["battery"])
    cyc = [x.strip() for x in raw["cyc"].split("@@")] + ["", "", ""]
    cycles, full, design = _int(cyc[0]), _int(cyc[1]), _int(cyc[2])
    bat["cycles"] = cycles
    bat["health_pct"] = round(100.0 * full / design) if full and design and 0 < full <= design * 1.2 else None
    cpu = parse_cpu(raw["cpu"])
    cpu["temp_c"] = parse_thermal(raw["thermal"])
    cpu["abi"] = props.get("ro.product.cpu.abi")
    cpu["hardware"] = props.get("ro.hardware") or props.get("ro.board.platform")
    wm = re.search(r"Physical size:\s*(\S+)", raw["wm"])
    dn = re.search(r"Physical density:\s*(\d+)", raw["wm"])
    brand = props.get("ro.product.brand") or props.get("ro.product.manufacturer") or ""
    model = props.get("ro.product.marketname") or props.get("ro.config.marketing_name") or props.get("ro.product.model") or dev.get("model", "Android")
    info = {
        "serial": serial, "name": (model if model.lower().startswith(brand.lower()) else (brand.capitalize() + " " + model)).strip(),
        "brand": brand, "model": props.get("ro.product.model"), "android": props.get("ro.build.version.release"),
        "sdk": props.get("ro.build.version.sdk"), "patch": props.get("ro.build.version.security_patch"),
        "bootloader_locked": props.get("ro.boot.flash.locked"), "verified_boot": props.get("ro.boot.verifiedbootstate"),
        "battery": bat, "memory": parse_meminfo(raw["mem"]), "storage": parse_df(raw["df"]), "cpu": cpu,
        "display": {"size": wm.group(1) if wm else None, "density": dn.group(1) if dn else None},
        "features": len(feats), "sensors": len([f for f in feats if f.startswith("android.hardware.sensor.")]),
        "apps": {"third_party": len(parse_pkgs(raw["pk3"])), "total": len(parse_pkgs(raw["pkall"]))},
        "network": {"wifi_on": raw["wifi"].strip() == "1", "bt_on": raw["bt"].strip() == "1",
                    "net_type": props.get("gsm.network.type"), "sim_state": props.get("gsm.sim.state")},
        "stor_split": parse_diskstats(raw["disk"]), "tests": tests_available(feats),
        "imei": None, "imei_note": "Not exposed by Android 10+ without system privileges",
        "collected": int(time.time()),
    }
    return info


def autotests(serial, names):
    res, bat = {}, None
    rc, out, _ = ADB.sh(serial, "dumpsys battery", 15)
    bat = parse_battery(out)
    for n in names:
        r = {"result": 0, "note": "Manual test: press PASS or FAIL"}
        try:
            if n == "Battery":
                if bat["health"] in ("Good",):
                    r = {"result": 1, "note": "Battery health: Good, level %s%%" % bat["level"]}
                elif bat["health"] in ("Overheat", "Dead", "Failure", "Over voltage"):
                    r = {"result": 2, "note": "Battery health: " + bat["health"]}
                else:
                    r = {"result": 0, "note": "Battery health not reported by this phone"}
            elif n == "Charge":
                ok = bat["ac"] or bat["usb"] or bat["wireless"] or bat["status"] in ("Charging", "Full")
                r = {"result": 1 if ok else 0, "note": "Power source detected: %s" % bat["status"] if ok else "No charger detected"}
            elif n == "Storage":
                cmd = "dd if=/dev/zero of=/data/local/tmp/pl_test.bin bs=1048576 count=32 2>&1; ls -l /data/local/tmp/pl_test.bin; rm -f /data/local/tmp/pl_test.bin"
                t0 = time.time()
                rc, o, _ = ADB.sh(serial, cmd, 40)
                dt = max(time.time() - t0, 0.01)
                ok = "33554432" in o
                r = {"result": 1 if ok else 2, "note": ("Wrote 32 MB in %.1f s (includes ADB overhead)" % dt) if ok else "Write test failed: " + o.strip()[:80]}
            elif n == "WiFi":
                rc, o, _ = ADB.sh(serial, "settings get global wifi_on", 10)
                r = {"result": 1 if o.strip() == "1" else 0, "note": "Wi-Fi is on" if o.strip() == "1" else "Turn Wi-Fi on, then run again"}
            elif n == "Bluetooth":
                rc, o, _ = ADB.sh(serial, "settings get global bluetooth_on", 10)
                r = {"result": 1 if o.strip() == "1" else 0, "note": "Bluetooth is on" if o.strip() == "1" else "Turn Bluetooth on, then run again"}
            elif n == "SIM Reader":
                rc, o, _ = ADB.sh(serial, "getprop gsm.sim.state", 10)
                ok = "READY" in o
                r = {"result": 1 if ok else 0, "note": "SIM state: " + (o.strip() or "unknown")}
            elif n == "Vibration":
                for c in ("cmd vibrator_manager synced oneshot 400 -1", "cmd vibrator vibrate 400 -f", "cmd vibrator vibrate 400"):
                    rc, o, _ = ADB.sh(serial, c, 10)
                    if rc == 0 and "rror" not in o and "nknown" not in o:
                        r = {"result": 0, "note": "Vibration command sent: confirm by touch, then press PASS or FAIL"}
                        break
        except Exception as e:  # one failing test must not stop the others
            LOG.warning("autotest %s failed: %s", n, e)
            r = {"result": 0, "note": "Could not run: %s" % e}
        res[n] = r
    return res


def scan_job(job, serial):
    items, napps, nfiles = [], 0, 0
    rc, out, _ = ADB.sh(serial, "pm list packages -3 -i", 20)
    pk = parse_pkgs(out)[:40]
    napps = len(pk)
    for i, (pkg, inst) in enumerate(pk):
        job["p"], job["msg"] = int(80.0 * i / max(len(pk), 1)), pkg
        rc, o, _ = ADB.sh(serial, "dumpsys package " + shlex.quote(pkg), 12)
        sideloaded = inst in (None, "null", "")
        level, dang = assess(parse_perms(o), sideloaded)
        if level in ("hg", "e3s") or (sideloaded and len(dang) >= 2):
            items.append([pkg, "Heuristic:Permissions" + ("+Sideloaded" if sideloaded else ""), "Riskware", 0, ", ".join(dang)])
    job["msg"], job["p"] = "files", 85
    rc, out, _ = ADB.sh(serial, "find /sdcard -maxdepth 3 -iname '*.apk' 2>/dev/null | head -50", 25)
    for path in [l.strip() for l in out.splitlines() if l.strip()]:
        nfiles += 1
        items.append([os.path.basename(path), "Heuristic:APK-file", "Riskware", 0, path])
    rc, out, _ = ADB.sh(serial, "ls /sdcard/Download /sdcard/Documents 2>/dev/null", 15)
    for name in [l.strip() for l in out.splitlines() if l.strip()]:
        nfiles += 1
        if re.search(r"\.(pdf|jpe?g|png|docx?|xlsx?|mp[34]|txt)\.(apk|exe|scr|bat|js|vbs)$", name, re.I):
            items.append([name, "Heuristic:DoubleExtension", "Riskware", 0, name])
    return {"items": items, "scanned": {"apps": napps, "files": nfiles},
            "note": "Heuristic analysis (permissions, install source, file names). Not an antivirus verdict."}


def docs_dir(serial):
    return os.path.join(os.path.expanduser("~"), "Documents", "PHONELAB", serial)


def pull_job(job, serial, paths):
    dest = docs_dir(serial)
    os.makedirs(dest, exist_ok=True)
    lines = []
    for i, p in enumerate(paths):
        job["p"], job["msg"] = int(100.0 * i / max(len(paths), 1)), p
        rc, out, err = ADB.cmd(serial, "pull", p, dest, timeout=3600)
        lines.append((out.strip().splitlines() or [err.strip()])[-1][:200])
    return {"dest": dest, "lines": lines}


def backup_job(job, serial):
    paths = []
    for p in ("/sdcard/DCIM", "/sdcard/Pictures", "/sdcard/Documents", "/sdcard/Download"):
        rc, out, _ = ADB.sh(serial, "ls -d " + p, 10)
        if rc == 0 and p in out:
            paths.append(p)
    if not paths:
        return {"dest": docs_dir(serial), "lines": ["Nothing to back up"]}
    return pull_job(job, serial, paths)


def live_sample(serial):
    cmd = ("head -3 /proc/meminfo; echo @@; "
           "for f in /sys/devices/system/cpu/cpu[0-9]*/cpufreq/scaling_cur_freq; do cat $f 2>/dev/null; done; echo @@; "
           "for f in /sys/devices/system/cpu/cpu[0-9]*/cpufreq/cpuinfo_max_freq; do cat $f 2>/dev/null; done; echo @@; "
           "echo 0; echo @@; dumpsys battery")
    rc, out, _ = ADB.sh(serial, cmd, 15)
    p = out.split("@@")
    p += [""] * (5 - len(p))
    mem = parse_meminfo(p[0] + "\n")
    cpu = parse_cpu(p[1] + "@@" + p[2] + "@@0")
    bat = parse_battery(p[4])
    return {"cpu": cpu["load_pct"], "ram": mem["used_pct"] if mem else None, "temp": bat["temp_c"], "bat": bat["level"], "t": int(time.time())}


JOBS = {}


def start_job(fn, *a):
    jid = secrets.token_hex(6)
    JOBS[jid] = {"status": "running", "p": 0, "msg": "", "result": None}

    def work():
        job = JOBS[jid]
        try:
            job["result"] = fn(job, *a)
            job["status"] = "done"
        except Exception as e:
            LOG.error("job failed: %s\n%s", e, traceback.format_exc())
            job["status"], job["msg"] = "error", str(e)
        job["p"] = 100

    threading.Thread(target=work, daemon=True).start()
    if len(JOBS) > 50:
        for k in list(JOBS)[:20]:
            JOBS.pop(k, None)
    return jid


def report_path(serial):
    d = os.path.join(DATA, "reports")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, serial + ".json")


# ----------------------------------------------------------------- http server
PNG = b"\x89PNG\r\n\x1a\n"


class Handler(BaseHTTPRequestHandler):
    server_version = "PHONELAB/" + VERSION
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def send(self, code, body, ctype="application/json; charset=utf-8"):
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def js(self, obj, code=200):
        self.send(code, json.dumps(obj, ensure_ascii=False))

    def allowed(self, q):
        host = (self.headers.get("Host") or "").rsplit(":", 1)[0]
        if host not in ("127.0.0.1", "localhost"):
            return False
        return (self.headers.get("X-PL-Token") or (q.get("k") or [""])[0]) == TOKEN

    def serial(self, q):
        s = (q.get("serial") or [""])[0]
        return s if SERIAL_RE.match(s) else None

    def handle_any(self, method):
        try:
            u = urlparse(self.path)
            q = parse_qs(u.query)
            body = {}
            if method == "POST":
                n = int(self.headers.get("Content-Length") or 0)
                if n:
                    body = json.loads(self.rfile.read(min(n, 1 << 20)).decode("utf-8") or "{}")
            p = u.path
            if p in ("/", "/index.html"):
                return self.index()
            if p == "/api/ping":
                return self.js({"app": "phonelab", "version": VERSION})
            if not self.allowed(q):
                return self.js({"error": "forbidden"}, 403)
            if p == "/api/health":
                return self.js({"ok": True, "version": VERSION, "adb": ADB.path or find_adb(), "adb_version": ver_line(),
                                "os": platform.platform(), "python": sys.version.split()[0], "data_dir": DATA})
            if p == "/api/devices":
                rc, devs, err = ADB.devices()
                return self.js({"adb_missing": rc == -2, "devices": devs, "error": err.strip() if rc not in (0, -2) else ""})
            if p == "/api/quit":
                threading.Thread(target=self.server.shutdown, daemon=True).start()
                return self.js({"ok": True})
            if p == "/api/job":
                return self.js(JOBS.get((q.get("id") or [""])[0]) or {"status": "unknown"})
            s = body.get("serial") if method == "POST" else self.serial(q)
            if not s or not SERIAL_RE.match(s):
                return self.js({"error": "bad_serial"}, 400)
            if p == "/api/info":
                return self.js(collect_info(s))
            if p == "/api/autotests":
                names = [n for n in body.get("names", []) if n in CANON]
                return self.js(autotests(s, names))
            if p == "/api/live":
                return self.js(live_sample(s))
            if p == "/api/screen":
                rc, out, err = ADB.cmd(s, "exec-out", "screencap", "-p", timeout=10, binary=True)
                if rc == 0 and out.startswith(PNG):
                    return self.send(200, out, "image/png")
                return self.send(503, "screen unavailable", "text/plain")
            if p == "/api/files":
                path = (q.get("path") or ["/sdcard"])[0]
                if not path.startswith("/") or "\n" in path or "\x00" in path:
                    return self.js({"error": "bad_path"}, 400)
                rc, out, err = ADB.sh(s, "ls -la " + shlex.quote(path), 20)
                return self.js({"path": path, "entries": parse_ls(out), "error": "" if rc == 0 else (out or err).strip()[:200]})
            if p == "/api/scan":
                return self.js({"job": start_job(scan_job, s)})
            if p == "/api/apps":
                return self.js({"job": start_job(apps_job, s)})
            if p == "/api/backup":
                return self.js({"job": start_job(backup_job, s)})
            if p == "/api/pull":
                paths = [x for x in body.get("paths", []) if isinstance(x, str) and x.startswith("/")][:20]
                return self.js({"job": start_job(pull_job, s, paths)})
            if p == "/api/report":
                rp = report_path(s)
                if method == "POST":
                    with open(rp, "w", encoding="utf-8") as f:
                        json.dump({"saved": int(time.time()), "snapshot": body.get("snapshot")}, f)
                    return self.js({"ok": True})
                if os.path.isfile(rp):
                    with open(rp, encoding="utf-8") as f:
                        return self.js(json.load(f))
                return self.js({"snapshot": None})
            return self.js({"error": "not_found"}, 404)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            LOG.error("request failed: %s\n%s", self.path, traceback.format_exc())
            try:
                self.js({"error": "internal", "detail": str(e)[:200]}, 500)
            except Exception:
                pass

    def index(self):
        for d in (os.path.join(BASE, "ui"), os.path.join(HERE, "ui")):
            f = os.path.join(d, "index.html")
            if os.path.isfile(f):
                with open(f, encoding="utf-8") as fh:
                    return self.send(200, fh.read().replace("__TOKEN__", TOKEN), "text/html; charset=utf-8")
        return self.send(500, "ui/index.html not found", "text/plain")

    def do_GET(self):
        self.handle_any("GET")

    def do_POST(self):
        self.handle_any("POST")


def apps_job(job, serial):
    rc, out, _ = ADB.sh(serial, "pm list packages -3 -i", 20)
    pk = parse_pkgs(out)[:30]
    rows = []
    for i, (pkg, inst) in enumerate(pk):
        job["p"], job["msg"] = int(100.0 * i / max(len(pk), 1)), pkg
        rc, o, _ = ADB.sh(serial, "dumpsys package " + shlex.quote(pkg), 12)
        level, dang = assess(parse_perms(o), inst in (None, "null", ""))
        rows.append([pkg, " · ".join(dang[:4]) or "-", level])
    rows.sort(key=lambda r: {"hg": 0, "e3s": 1, "lw": 2}[r[2]])
    return {"apps": rows}


def make_server(port):
    return ThreadingHTTPServer(("127.0.0.1", port), Handler)


def setup_logging():
    os.makedirs(DATA, exist_ok=True)
    h = RotatingFileHandler(os.path.join(DATA, "phonelab.log"), maxBytes=500000, backupCount=2, encoding="utf-8")
    h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    LOG.addHandler(h)
    LOG.setLevel(logging.INFO)


def already_running(port):
    try:
        s = socket.create_connection(("127.0.0.1", port), timeout=1)
        s.sendall(b"GET /api/ping HTTP/1.0\r\nHost: 127.0.0.1\r\n\r\n")
        data = s.recv(2048)
        s.close()
        return b'"phonelab"' in data
    except OSError:
        return False


def say(msg):
    try:
        print(msg)
    except Exception:
        pass


def main():
    ap = argparse.ArgumentParser(description="CHARARA => PHONELAB")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args()
    try:
        sys.stdout.reconfigure(errors="replace")
    except Exception:
        pass
    setup_logging()
    LOG.info("start v%s on %s python %s", VERSION, platform.platform(), sys.version.split()[0])
    if args.selftest:
        say(json.dumps({"version": VERSION, "adb": find_adb(), "os": platform.platform()}))
        return 0
    if already_running(args.port):
        say("PHONELAB is already running: opening it.")
        webbrowser.open("http://127.0.0.1:%d/" % args.port)
        return 0
    srv = None
    for port in range(args.port, args.port + 20):
        try:
            srv = make_server(port)
            break
        except OSError:
            continue
    if srv is None:
        say("Could not open a local port (8765-8784 busy). Close other programs and retry.")
        return 1
    port = srv.server_address[1]
    threading.Thread(target=ADB.start, daemon=True).start()
    url = "http://127.0.0.1:%d/" % port
    say("=" * 58)
    say(" CHARARA => PHONELAB v%s" % VERSION)
    say(" Open: %s   (close this window to quit)" % url)
    say(" adb: %s" % (find_adb() or "NOT FOUND (put adb.exe in the 'tools' folder)"))
    say("=" * 58)
    if not args.no_browser:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        srv.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
